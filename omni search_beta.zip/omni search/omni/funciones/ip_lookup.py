import urllib.request
import json

def buscar(consulta):
    objetivo = consulta.strip() if consulta else ""

    url = f"http://ip-api.com/json/{objetivo}?fields=status,message,continent,country,countryCode,region,regionName,city,zip,lat,lon,timezone,isp,org,as,mobile,proxy,hosting,query"
    
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as response:
            datos = json.loads(response.read().decode('utf-8'))
            
            if datos.get("status") == "success":
                return {
                    "ip": datos.get("query"),
                    "continent": datos.get("continent"),
                    "country": f"{datos.get('country')} ({datos.get('countryCode')})",
                    "region": datos.get("regionName"),
                    "city": datos.get("city"),
                    "zip_code": datos.get("zip"),
                    "latitude": datos.get("lat"),
                    "longitude": datos.get("lon"),
                    "asn": datos.get("as"),
                    "isp": datos.get("isp"),
                    "organization": datos.get("org"),
                    "timezone": datos.get("timezone"),
                    "is_mobile": datos.get("mobile"),
                    "is_proxy_vpn": datos.get("proxy"),
                    "is_hosting": datos.get("hosting"),
                    "status": datos.get("status")
                }
            else:
                return {"error": f"Error buscando la IP: {datos.get('message')}", "ip": objetivo}
                
    except Exception as e:
        return {"error": f"Fallo al conectar con el servidor: {str(e)}", "ip": objetivo}
