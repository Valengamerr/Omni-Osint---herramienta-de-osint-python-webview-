import urllib.request
import json

def buscar(consulta):
    uid = consulta.strip()
    if not uid.isdigit():
        return {"error": "Ingresa un ID de Roblox válido (sólo números)"}


    url = f"https://users.roblox.com/v1/users/{uid}"
    
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as response:
            datos = json.loads(response.read().decode('utf-8'))
            
            return {
                "id": datos.get("id"),
                "username": datos.get("name"),
                "display_name": datos.get("displayName"),
                "description": datos.get("description"),
                "created_at": datos.get("created"),
                "is_banned": datos.get("isBanned"),
                "has_verified_badge": datos.get("hasVerifiedBadge", False)
            }
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return {"error": "Usuario de Roblox no encontrado"}
        return {"error": f"Error de Roblox API: {e.code}"}
    except Exception as e:
        return {"error": f"Fallo al conectar: {str(e)}"}
