import urllib.parse

def buscar(consulta):
    partes = consulta.split('|')
    objetivo = partes[0] if partes[0] else "example.com"
    tipo_dork = partes[1] if len(partes) > 1 else "social_media"
    
    busquedas = {
        "social_media": f"site:twitter.com OR site:facebook.com OR site:instagram.com OR site:linkedin.com \"{objetivo}\"",
        "index_of": f"intitle:\"index of\" \"{objetivo}\"",
        "databases": f"ext:sql OR ext:db OR ext:csv site:{objetivo}",
        "documents": f"ext:pdf OR ext:doc OR ext:docx OR ext:xls OR ext:xlsx site:{objetivo}",
        "env_keys": f"ext:env OR ext:log OR ext:yml site:{objetivo} \"password\" OR \"key\" OR \"secret\""
    }
    
    query_dork = busquedas.get(tipo_dork, busquedas["social_media"])
    google_url = f"https://www.google.com/search?q={urllib.parse.quote(query_dork)}"
    
    return {
        "target": objetivo,
        "dork_type": tipo_dork,
        "generated_query": query_dork,
        "google_search_link": google_url,
        "status": "Ready"
    }
