import webview
import time
from funciones import ip_lookup, number_lookup, web, discord_id_info, roblox_id_info, discord_server_info, google_dork, tiktok_user_info, email_tracker, database_search

class Api:
    def realizar_busqueda(self, tipo_busqueda, consulta):
        inicio = time.time()
        resultados = None
        cantidad = 0
        estado = "exito"
        

        db_resultados = None
        try:
            db_resultados = database_search.buscar(consulta)
        except Exception:
            pass

        try:
            if tipo_busqueda == "ip_lookup":
                resultados = ip_lookup.buscar(consulta)
            elif tipo_busqueda == "number_lookup":
                resultados = number_lookup.buscar(consulta)
            elif tipo_busqueda == "web":
                resultados = web.buscar(consulta)
            elif tipo_busqueda == "discord_id_info":
                resultados = discord_id_info.buscar(consulta)
            elif tipo_busqueda == "roblox_id_info":
                resultados = roblox_id_info.buscar(consulta)
            elif tipo_busqueda == "discord_server_info":
                resultados = discord_server_info.buscar(consulta)
            elif tipo_busqueda == "google_dork":
                resultados = google_dork.buscar(consulta)
            elif tipo_busqueda == "tiktok_user_info":
                resultados = tiktok_user_info.buscar(consulta)
            elif tipo_busqueda == "email_tracker":
                resultados = email_tracker.buscar(consulta)
            elif tipo_busqueda == "database_search":
                resultados = db_resultados
                db_resultados = None
            elif tipo_busqueda == "qr_generator":
                resultados = qr.buscar(consulta)
            else:
                estado = "error"
                resultados = "Tipo de busqueda invalido"
                
            if isinstance(resultados, list):
                cantidad = len(resultados)
            elif isinstance(resultados, dict):
                cantidad = len(resultados.keys())
            elif resultados:
                cantidad = 1
                
        except Exception as e:
            estado = "error"
            resultados = str(e)
            
        tiempo_transcurrido = round(time.time() - inicio, 2)
        
        return {
            "type": tipo_busqueda,
            "count": cantidad,
            "time": round(tiempo_transcurrido, 2),
            "data": resultados,
            "db_results": db_resultados,
            "status": estado
        }

    def abrir_historial(self):
        try:
            webview.create_window(
                'Historial de Busquedas', 
                'funciones/historial/hist.html',
                width=400, 
                height=600,
                background_color='#0f0f13'
            )
        except Exception as e:
            print(e)
        return True

if __name__ == '__main__':
    api = Api()
    ventana = webview.create_window(
        'Omni Search Interface', 
        'index.html', 
        js_api=api, 
        width=1100, 
        height=750,
        background_color='#0f0f13'
    )
    webview.start(debug=True)
