import urllib.request
import json
import dns.resolver

def buscar(consulta):
    correo = consulta.strip()
    if '@' not in correo:
        return {"error": "Formato de correo invalido"}
        
    dominio = correo.split('@')[1]
    resultado = {
        "email_address": correo,
        "domain": dominio,
        "mx_records_found": False
    }

    # 1. Comprobar registros MX para ver si el correo puede recibir mensajes (usando dns.resolver local)
    try:
        registros_mx = dns.resolver.resolve(dominio, 'MX')
        servidores_mx = [str(reg.exchange) for reg in registros_mx]
        resultado["mx_records_found"] = True
        resultado["mail_servers"] = servidores_mx
    except Exception:
         resultado["mx_records_found"] = False
         resultado["smtp_status"] = "No se pudieron obtener registros MX (Posible dominio falso/inactivo)"

    # 2. Correo desechable basico
    temp_domains = ["mailinator.com", "10minutemail.com", "tempmail.com", "yopmail.com", "guerrillamail.com"]
    resultado["is_disposable"] = any(temp in dominio.lower() for temp in temp_domains)

    # 3. Have I Been Pwned check (Requiere API KEY en produccion, probaremos el endpoint gratis viejo/ofuscado o retornaremos limite)
    hibp_url = f"https://haveibeenpwned.com/api/v3/breachedaccount/{urllib.parse.quote(correo)}"
    try:
        # Nota: La API v3 de HIBP requiere clave hoy en dia, simularemos un fetch fallido intencional 
        # para mostrar OSINT pero no bloquearemos el app.
        req = urllib.request.Request(hibp_url, headers={'User-Agent': 'Mozilla/5.0', 'hibp-api-key': 'none'})
        try:
             with urllib.request.urlopen(req, timeout=5) as response:
                  datos = json.loads(response.read().decode('utf-8'))
                  resultado["breach_count"] = len(datos)
                  resultado["known_breaches"] = [b.get("Name") for b in datos]
        except urllib.error.HTTPError as e:
            if e.code == 404:
                resultado["breach_count"] = 0
                resultado["data_breach_status"] = "El correo esta limpio, no aparece en ninguna base de datos publica filtrada."
            elif e.code == 401:
                resultado["data_breach_status"] = "Análisis de Fugas profundo deshabilitado (Requiere llave HIBP)."
                
    except Exception:
         pass

    return resultado
