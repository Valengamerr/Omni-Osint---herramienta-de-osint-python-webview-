import urllib.request
import json

def buscar(consulta):
    uid = consulta.strip()
    if not uid.isdigit():
        return {"error": "Ingresa un ID de Discord válido (sólo números)"}

    url = f"https://discordlookup.mesalytic.moe/v1/user/{uid}"
    
    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as response:
            datos = json.loads(response.read().decode('utf-8'))
            
            badges_list = datos.get("badges", [])
            badges = ", ".join(badges_list) if badges_list else "Ninguna"

            return {
                "id": datos.get("id"),
                "username": f"{datos.get('username')}",
                "global_name": datos.get("global_name"),
                "created_at": datos.get("created_at"),
                "badges": badges,
                "bot": datos.get("bot", False),
                "avatar_url": datos.get("avatar", {}).get("link", "Vacio"),
                "banner_url": datos.get("banner", {}).get("link", "Vacio"),
                "banner_color": datos.get("banner", {}).get("color", "Vacio")
            }
    except Exception as e:
        return {"error": f"Fallo buscando al usuario: El ID quizas no existe o el servicio falló. ({e})"}
