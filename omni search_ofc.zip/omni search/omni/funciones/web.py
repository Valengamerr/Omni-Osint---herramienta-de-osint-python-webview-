import socket
import ssl
import urllib.request
import json
import concurrent.futures

def get_website_info(dominio):
    resultado = {}
    try:
        ip = socket.gethostbyname(dominio)
        resultado["ip_address"] = ip
    except Exception as e:
        resultado["ip_address_error"] = str(e)

    try:
        req = urllib.request.Request(f"http://{dominio}", headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=5) as response:
            headers = dict(response.headers)
            resultado["server"] = headers.get('Server', 'Desconocido')
            resultado["x_powered_by"] = headers.get('X-Powered-By', 'No disponible')
    except Exception:
        resultado["server"] = "No se pudo obtener Headers"

    try:
        ctx = ssl.create_default_context()
        with ctx.wrap_socket(socket.socket(), server_hostname=dominio) as s:
            s.settimeout(5.0)
            s.connect((dominio, 443))
            cert = s.getpeercert()
            issuer = dict(x[0] for x in cert['issuer'])
            resultado["ssl_certificate_issuer"] = issuer.get('organizationName', 'Desconocido')
            resultado["ssl_certificate_valid_from"] = cert.get('notBefore')
            resultado["ssl_is_valid"] = True
    except Exception as e:
        resultado["ssl_error"] = str(e)
        resultado["ssl_is_valid"] = False

    return resultado

def get_subdomains(dominio):
    try:
        url = f"https://crt.sh/?q=%25.{dominio}&output=json"
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as response:
            datos = json.loads(response.read().decode('utf-8'))
            subdominios_unicos = set()
            for entry in datos:
                name = entry.get('name_value', '')
                if name.endswith(dominio) and '*' not in name:
                    for n in name.split('\n'):
                        n = n.strip()
                        if n and n != dominio:
                            subdominios_unicos.add(n)
            lista = sorted(list(subdominios_unicos))[:40] # Allow up to 40 subdomains
            if not lista:
                return ["Ninguno encontrado (Quizás está oculto)"]
            return lista
    except Exception as e:
        return [f"Error de conexión con crt.sh: {e}"]

def scan_ports(dominio):
    puertos = [21, 22, 23, 25, 53, 80, 110, 143, 443, 3306, 8080, 8443]
    resultados = []
    
    def probar_puerto(port):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(1.0)
        try:
            s.connect((dominio, port))
            return (port, "Abierto (Open)")
        except:
            return (port, "Cerrado/Filtrado")
        finally:
            s.close()
            
    with concurrent.futures.ThreadPoolExecutor(max_workers=len(puertos)) as executor:
        futures = {executor.submit(probar_puerto, p): p for p in puertos}
        for future in concurrent.futures.as_completed(futures):
            puerto, estado = future.result()
            resultados.append(f"Port {puerto}: {estado}")

    resultados.sort(key=lambda x: int(x.split()[1].replace(':', '')))
    return resultados

def buscar(consulta):
    dominio = consulta.replace('https://', '').replace('http://', '').replace('/', '').strip()
    if not dominio:
        return {"error": "Ingresa un dominio valido"}

    info = get_website_info(dominio)
    subdominios = get_subdomains(dominio)
    puertos = scan_ports(dominio)

    return {
        "domain": dominio,
        "web_details": info,
        "subdomains_list": subdominios,
        "port_scan_log": puertos
    }
