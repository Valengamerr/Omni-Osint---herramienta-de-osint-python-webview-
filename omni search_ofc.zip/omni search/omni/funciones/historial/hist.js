document.addEventListener('DOMContentLoaded', () => {
    cargarHistorial();

    document.getElementById('clear-history').addEventListener('click', () => {
        localStorage.removeItem('omniSearchHistory');
        cargarHistorial();
    });
});

function cargarHistorial() {
    const list = document.getElementById('hist-list');
    list.innerHTML = '';

    let historyStr = localStorage.getItem('omniSearchHistory');
    let history = [];
    if (historyStr) {
        try {
            history = JSON.parse(historyStr);
        } catch (e) { }
    }

    if (history.length === 0) {
        list.innerHTML = '<div class="no-data">No hay búsquedas recientes</div>';
        return;
    }

    history.forEach(item => {
        const div = document.createElement('div');
        div.className = 'hist-item';
        div.innerHTML = `
            <div class="hist-top">
                <span class="hist-type">${item.type.replace(/_/g, ' ').toUpperCase()}</span>
                <span class="hist-time">${item.time}</span>
            </div>
            <div class="hist-query">${item.query}</div>
        `;
        list.appendChild(div);
    });
}

// Escuchar cambios en el localstorage para actualizar en vivo
window.addEventListener('storage', (e) => {
    if (e.key === 'omniSearchHistory') {
        cargarHistorial();
    }
});
