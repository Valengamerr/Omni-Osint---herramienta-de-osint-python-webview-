import urllib.parse

def buscar(consulta):
    texto = consulta or "https://example.com"
    codificado = urllib.parse.quote(texto)
    url_qr = f"https://api.qrserver.com/v1/create-qr-code/?size=250x250&data={codificado}"
    
    return {
        "message": "QR Image Generated Successfully",
        "raw_text": texto,
        "qr_image_url": url_qr,
        "format": "PNG",
        "size": "250x250 pixels"
    }
