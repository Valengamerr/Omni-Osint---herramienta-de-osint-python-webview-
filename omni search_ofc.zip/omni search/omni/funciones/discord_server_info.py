import urllib.request
import json

def buscar(consulta):
    codigo = consulta.split('/')[-1].strip() # Maneja tanto IDs directos como links de invitación
    if not codigo:
        return {"error": "Ingresa un código de invitación o ID de servidor"}

    # Usando API V9 Invite endpoint
    url = f"https://discord.com/api/v9/invites/{codigo}?with_counts=true&with_expiration=true"
    
    try:
        req = urllib.request.Request(url, headers={
            'User-Agent': 'Mozilla/5.0',
            'Accept': 'application/json'
        })
        with urllib.request.urlopen(req, timeout=10) as response:
            datos = json.loads(response.read().decode('utf-8'))
            
            guild = datos.get("guild", {})
            return {
                "server_id": guild.get("id"),
                "server_name": guild.get("name"),
                "description": guild.get("description", "Sin descripción"),
                "member_count": datos.get("approximate_member_count", 0),
                "online_members": datos.get("approximate_presence_count", 0),
                "verification_level": guild.get("verification_level"),
                "premium_subscription_count": guild.get("premium_subscription_count", 0),
                "features": guild.get("features", []),
                "nsfw_level": guild.get("nsfw_level"),
                "vanity_url_code": guild.get("vanity_url_code", "Ninguno"),
                "icon_url": f"https://cdn.discordapp.com/icons/{guild.get('id')}/{guild.get('icon')}.png" if guild.get('icon') else "Sin icono",
                "invite_channel": datos.get("channel", {}).get("name", "Desconocido")
            }
    except Exception as e:
        return {"error": "Invitación inválida o expirada. Asegúrate de poner el código correcto (ej: discord.gg/codigo)."}
