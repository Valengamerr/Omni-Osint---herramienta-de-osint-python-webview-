import os
import json
import glob

def buscar(consulta):
    query = consulta.strip().lower()
    if not query:
        return {"error": "Ingresa un término válido para buscar en las bases de datos"}
    
    db_folder = os.path.join(os.path.dirname(os.path.dirname(__file__)), "database")
    if not os.path.exists(db_folder):
        return {"error": "La carpeta 'database' no existe. Crea una en la raíz del proyecto."}

    archivos_json = glob.glob(os.path.join(db_folder, "*.json"))
    
    if not archivos_json:
        return {"error": "No hay archivos .json en la carpeta 'database'."}
        
    resultados_encontrados = []
    

    for path in archivos_json:
        db_name = os.path.basename(path)
        try:
            with open(path, 'r', encoding='utf-8') as f:
                datos = json.load(f)
                

                if isinstance(datos, list):
                    for item in datos:

                        if any(query in str(val).lower() for val in item.values()):
                            item_copia = item.copy()
                            item_copia["_source_db"] = db_name 
                            resultados_encontrados.append(item_copia)
                            
                elif isinstance(datos, dict):
                    for k, v in datos.items():
                        if query in str(k).lower() or query in str(v).lower():
                            resultados_encontrados.append({
                                "_source_db": db_name,
                                "matched_key": k,
                                "matched_value": v
                            })
                            
        except Exception as e:
            pass
            
    if not resultados_encontrados:
        return {"message": "No se encontraron coincidencias en ninguna base de datos local."}
        
    return resultados_encontrados
