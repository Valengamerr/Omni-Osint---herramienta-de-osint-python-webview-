import urllib.request
import json
import re

def buscar(consulta):
    usuario = consulta.replace('@', '') if consulta else "tiktok"
    url = f"https://www.tiktok.com/@{usuario}"
    
    try:
        req = urllib.request.Request(
            url, 
            headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'}
        )
        with urllib.request.urlopen(req, timeout=5) as response:
            html = response.read().decode('utf-8')
            
        match = re.search(r'<script id="__UNIVERSAL_DATA_FOR_REHYDRATION__" type="application/json">(.*?)</script>', html)
        if match:
            data = json.loads(match.group(1))
            user_module = data.get("__DEFAULT_SCOPE__", {}).get("webapp.user-detail", {}).get("userInfo", {})
            user = user_module.get("user", {})
            stats = user_module.get("stats", {})
            
            if user:
                return {
                    "username": f"@{user.get('uniqueId')}",
                    "id": user.get('id'),
                    "nickname": user.get('nickname'),
                    "signature": user.get('signature'),
                    "following_count": stats.get('followingCount'),
                    "follower_count": stats.get('followerCount'),
                    "heart_count": stats.get('heartCount'),
                    "video_count": stats.get('videoCount'),
                    "verified": user.get('verified'),
                    "region": user.get('region'),
                    "avatar_url": user.get('avatarLarger')
                }
    except Exception:
        pass
        
    return {
        "error": "Anti-Bot Request Blocked / User Not Found",
        "username": consulta or "no encontrado",
        "id": "no encontrado",
        "nickname": "no encontrado",
        "signature": "no encontrado",
        "following_count": "no encontrado",
        "follower_count": "no encontrado",
        "heart_count": "no encontrado",
        "video_count": "no encontrado",
        "verified": "no encontrado",
        "region": "no encontrado",
        "avatar_url": "no encontrado"
    }
