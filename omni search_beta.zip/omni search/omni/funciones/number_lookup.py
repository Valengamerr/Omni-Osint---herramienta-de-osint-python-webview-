import urllib.request
import json
import phonenumbers


def buscar(consulta):
    numero = consulta.strip() if consulta else ""
    if not numero:
        return {"error": "Ingresa un número telefónico"}

    url = f"https://api.numlookupapi.com/v1/validate/{numero}"
    

    try:
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        with urllib.request.urlopen(req, timeout=10) as response:
            datos = json.loads(response.read().decode('utf-8'))
            if datos.get("valid"):
                return {
                    "number": datos.get("number"),
                    "local_format": datos.get("local_format"),
                    "international_format": datos.get("international_format"),
                    "country_prefix": datos.get("country_prefix"),
                    "country_code": datos.get("country_code"),
                    "country_name": datos.get("country_name"),
                    "location": datos.get("location"),
                    "carrier": datos.get("carrier"),
                    "line_type": datos.get("line_type")
                }
    except Exception:
        pass


    clean_num = "".join(filter(str.isdigit, numero))
    if len(clean_num) > 6:
        return {
            "error": "Límite de API / Solo mostrando análisis general",
            "number": consulta,
            "numeric_only": clean_num,
            "length": len(clean_num),
            "approx_valid": True,
            "note": "Recomendable usar phonenumbers (Python env)"
        }
    return {"error": "Número inválido o API no disponible"}
