// javascript creado por uknowuser_qq en discord
// archivos python creados por uknowuser_qq en discord
// archivos html & css creados por uknowuser_qq en discord

const translations = {
    es: {
        selected: "Seleccionado",
        dork_social: "Redes Sociales",
        dork_index: "Index Of (Archivos Abiertos)",
        dork_db: "Bases de Datos (SQL, CSV)",
        dork_docs: "Documentos (PDF, Excel)",
        dork_keys: "Env Keys & Passwords",
        search: "Buscar",
        busqueda: "búsqueda",
        total: "total encontrado",
        tiempo: "tiempo de búsqueda",
        completed: "Búsqueda completada",
        results_details: "Detalles",
        placeholders: {
            'ip_lookup': 'Ingresa dirección IP...',
            'number_lookup': 'Ingresa número de teléfono...',
            'web': 'Ingresa dominio objetivo...',
            'discord_id_info': 'Ingresa Discord ID...',
            'google_dork': 'Ingresa objetivo (ej. empresa.com)...',
            'tiktok_user_info': 'Ingresa usuario de TikTok...',
            'email_tracker': 'Ingresa correo electrónico...',
            'qr_generator': 'Ingresa texto o URL...',
            'database_search': 'Ingresa valor a buscar en DB...'
        },
        labels: {
            'ip_lookup': 'IP Lookup',
            'number_lookup': 'Number Lookup',
            'web': 'Escáner Web',
            'discord_id_info': 'Discord ID Info',
            'google_dork': 'Google Dorks',
            'tiktok_user_info': 'TikTok User Info',
            'email_tracker': 'Email Tracker',
            'qr_generator': 'QR Generator'
        },
        keys: {
            "message": "Mensaje",
            "raw_text": "Texto Base",
            "format": "Formato",
            "size": "Tamaño",
            "ip": "Dirección IP",
            "hostname": "Nombre de Host",
            "continent": "Continente",
            "country": "País",
            "region": "Región",
            "city": "Ciudad",
            "zip_code": "Cód. Postal",
            "latitude": "Latitud",
            "longitude": "Longitud",
            "asn": "ASN",
            "isp": "Proveedor ISP",
            "organization": "Organización",
            "timezone": "Zona Horaria",
            "proxy": "Proxy",
            "hosting": "Hosting",
            "status": "Estado",
            "number": "Número",
            "international_format": "Formato Int.",
            "local_format": "Formato Local",
            "country_prefix": "Prefijo País",
            "country_code": "Cód. País",
            "country_name": "Nombre País",
            "location": "Ubicación",
            "carrier": "Operadora",
            "line_type": "Tipo Línea",
            "is_valid": "Es Válido",
            "timezones": "Zonas Horarias",
            "domain": "Dominio",
            "ip_address": "Dir. IP",
            "server": "Servidor",
            "hosting_provider": "Proveedor Hosting",
            "technologies": "Tecnologías",
            "ssl_certificate_issuer": "Emisor SSL",
            "ssl_certificate_valid_from": "SSL Válido Desde",
            "ssl_certificate_valid_to": "SSL Válido Hasta",
            "ssl_is_valid": "SSL Válido",
            "dns_a": "Registros A",
            "dns_mx": "Registros MX",
            "dns_txt": "Registros TXT",
            "whois_registrar": "Registrador (Whois)",
            "whois_creation_date": "Creado el",
            "whois_expiration_date": "Expira el",
            "id": "ID",
            "username": "Usuario",
            "global_name": "Nombre Global",
            "avatar": "Avatar",
            "banner": "Banner",
            "banner_color": "Color Banner",
            "accent_color": "Color Acento",
            "created_at": "Creado el",
            "badges": "Insignias",
            "bot": "Es Bot",
            "premium_type": "Tipo Premium",
            "public_flags": "Banderas Públicas",
            "display_name": "Nombre a Mostrar",
            "description": "Descripción",
            "is_banned": "Está Baneado",
            "has_premium": "Tiene Premium",
            "friends_count": "Amigos",
            "followers_count": "Seguidores",
            "following_count": "Siguiendo",
            "avatar_url": "URL Avatar",
            "server_id": "ID Servidor",
            "server_name": "Nombre Servidor",
            "owner_id": "ID Dueño",
            "member_count": "Miembros",
            "online_members": "En Línea",
            "verification_level": "Nivel Verificación",
            "boost_level": "Nivel Boost",
            "boost_count": "Boosts",
            "features": "Características",
            "icon_url": "URL Icono",
            "target": "Objetivo",
            "dork_type": "Tipo de Dork",
            "generated_query": "Búsqueda Generada",
            "google_search_link": "Enlace Google",
            "nickname": "Apodo",
            "signature": "Firma",
            "heart_count": "Me Gustas",
            "video_count": "Videos",
            "verified": "Verificado",
            "email_address": "Correo Electrónico",
            "is_valid_format": "Formato Válido",
            "is_disposable": "Desechable",
            "mx_records_found": "Registros MX",
            "smtp_check": "Verificación SMTP",
            "breach_count": "Nº Fugas",
            "known_breaches": "Fugas Conocidas",
            "associated_names": "Nombres Asociados",
            "error": "Error"
        }
    },
    en: {
        selected: "Selected",
        dork_social: "Social Media",
        dork_index: "Index Of (Open Files)",
        dork_db: "Databases (SQL, CSV)",
        dork_docs: "Documents (PDF, Excel)",
        dork_keys: "Env Keys & Passwords",
        search: "Search",
        busqueda: "search",
        total: "total found",
        tiempo: "search time",
        completed: "Search completed",
        results_details: "Results Details",
        placeholders: {
            'ip_lookup': 'Enter IP address...',
            'number_lookup': 'Enter phone number...',
            'web': 'Enter target domain...',
            'discord_id_info': 'Enter Discord ID...',
            'google_dork': 'Enter target (e.g. company.com)...',
            'tiktok_user_info': 'Enter TikTok user...',
            'email_tracker': 'Enter email address...',
            'qr_generator': 'Enter text or URL...',
            'database_search': 'Enter database search query...'
        },
        labels: {
            'ip_lookup': 'IP Lookup',
            'number_lookup': 'Number Lookup',
            'web': 'Web Scanner',
            'discord_id_info': 'Discord ID Info',
            'google_dork': 'Google Dorks',
            'tiktok_user_info': 'TikTok User Info',
            'email_tracker': 'Email Tracker',
            'qr_generator': 'QR Generator',
            'database_search': 'Database Search'
        },
        keys: {} 
    },
    ru: {
        selected: "Выбрано",
        dork_social: "Социальные сети",
        dork_index: "Index Of (Открытые файлы)",
        dork_db: "Базы данных (SQL, CSV)",
        dork_docs: "Документы (PDF, Excel)",
        dork_keys: "Ключи Env и пароли",
        search: "Поиск",
        busqueda: "поиск",
        total: "найдено",
        tiempo: "время",
        completed: "Поиск завершен",
        results_details: "Подробности",
        placeholders: {
            'ip_lookup': 'Введите IP...',
            'number_lookup': 'Введите телефон...',
            'web': 'Введите домен...',
            'discord_id_info': 'Введите Discord ID...',
            'google_dork': 'Введите цель...',
            'tiktok_user_info': 'Аккаунт TikTok...',
            'email_tracker': 'Введите почту...',
            'qr_generator': 'Текст или URL...',
            'database_search': 'Введите запрос для базы...'
        },
        labels: {
            'ip_lookup': 'IP Lookup',
            'number_lookup': 'Number Lookup',
            'web': 'Web Scanner',
            'discord_id_info': 'Discord ID Info',
            'google_dork': 'Google Dorks',
            'tiktok_user_info': 'TikTok User Info',
            'email_tracker': 'Email Tracker',
            'qr_generator': 'QR Generator',
            'database_search': 'Поиск по базе данных'
        },
        keys: {
            "message": "Сообщение",
            "status": "Статус",
            "error": "Ошибка"
        }
    },
    ar: {
        selected: "المحدد",
        dork_social: "وسائل التواصل الاجتماعي",
        dork_index: "Index Of (ملفات مفتوحة)",
        dork_db: "قواعد بيانات (SQL, CSV)",
        dork_docs: "مستندات (PDF, Excel)",
        dork_keys: "مفاتيح Env وكلمات مرور",
        search: "بحث",
        busqueda: "بحث",
        total: "العدد الإجمالي",
        tiempo: "وقت البحث",
        completed: "اكتمل البحث",
        results_details: "تفاصيل النتائج",
        placeholders: {
            'ip_lookup': 'أدخل عنوان IP...',
            'number_lookup': 'أدخل رقم الهاتف...',
            'web': 'أدخل النطاق...',
            'discord_id_info': 'أدخل معرف Discord...',
            'google_dork': 'أدخل الهدف (مثل company.com)...',
            'tiktok_user_info': 'أدخل مستخدم TikTok...',
            'email_tracker': 'أدخل البريد الإلكتروني...',
            'qr_generator': 'أدخل نص أو رابط...',
            'database_search': 'أدخل مصطلح البحث في قاعدة البيانات...'
        },
        labels: {
            'ip_lookup': 'بحث IP',
            'number_lookup': 'بحث رقم الإتصال',
            'web': 'معلومات الموقع',
            'discord_id_info': 'معلومات Discord ID',
            'google_dork': 'Google Dorks',
            'tiktok_user_info': 'معلومات مستخدم TikTok',
            'email_tracker': 'متتبع البريد الإلكتروني',
            'qr_generator': 'مولد QR',
            'database_search': 'البحث في قاعدة البيانات'
        },
        keys: {
            "message": "رسالة",
            "error": "خطأ",
            "status": "حالة"
        }
    }
};

let currentLang = 'es';
let currentSearchType = 'ip_lookup';
let currentIconClass = 'ph-globe-hemisphere-west';

document.addEventListener('DOMContentLoaded', () => {
    initParticles();
    initLanguage();
    initHistory();
    initUI();
    applyLanguage();
});

function initLanguage() {
    const langSelect = document.getElementById('lang-select');
    langSelect.addEventListener('change', (e) => {
        currentLang = e.target.value;
        applyLanguage();
    });
}

function applyLanguage() {
    const t = translations[currentLang];

    document.querySelectorAll('[data-i18n]').forEach(el => {
        const key = el.getAttribute('data-i18n');
        if (t[key]) el.textContent = t[key];
    });

    document.getElementById('search-btn').querySelector('span').textContent = t.search;

    const searchInput = document.getElementById('search-input');
    const selectedIndicator = document.getElementById('selected-text');
    searchInput.placeholder = t.placeholders[currentSearchType] || 'Enter target...';
    selectedIndicator.textContent = `${t.selected} : ${t.labels[currentSearchType] ? t.labels[currentSearchType].toLowerCase() : currentSearchType.replace('_', ' ')}`;


}

function initHistory() {
    const historyBtn = document.getElementById('history-btn');
    historyBtn.addEventListener('click', () => {
        if (window.pywebview && window.pywebview.api) {
            window.pywebview.api.abrir_historial();
        } else {
            alert("El historial requiere la app nativa en Python.");
        }
    });
}

function saveToHistory(searchType, query) {
    const now = new Date();
    const timeStr = now.toLocaleTimeString();

    let historyStr = localStorage.getItem('omniSearchHistory');
    let history = [];
    if (historyStr) {
        try { history = JSON.parse(historyStr); } catch (e) { }
    }

    history.unshift({ type: searchType, query: query, time: timeStr });
    if (history.length > 20) history.pop();

    localStorage.setItem('omniSearchHistory', JSON.stringify(history));
}

function initUI() {
    const typeIcons = document.querySelectorAll('.icon-wrapper');
    const searchInput = document.getElementById('search-input');
    const searchBtn = document.getElementById('search-btn');
    const loadingBar = document.getElementById('loading');
    const dorksMenu = document.getElementById('dorks-menu');
    const container = document.getElementById('results-container');

    typeIcons.forEach(icon => {
        icon.addEventListener('click', () => {
            typeIcons.forEach(i => i.classList.remove('active'));
            icon.classList.add('active');
            currentSearchType = icon.getAttribute('data-type');

            // Extract class for the icon (to put in results card)
            const iconEl = icon.querySelector('i');
            if (iconEl) {
                currentIconClass = Array.from(iconEl.classList).find(c => c.startsWith('ph-') && c !== 'ph');
            }

            if (currentSearchType === 'google_dork') {
                dorksMenu.classList.remove('hidden');
            } else {
                dorksMenu.classList.add('hidden');
            }

            applyLanguage();
            searchInput.focus();
        });
    });

    searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') performSearch();
    });

    searchBtn.addEventListener('click', performSearch);

    async function performSearch() {
        let query = searchInput.value.trim();

        if (currentSearchType === 'google_dork') {
            const dt = document.getElementById('dork-type-select').value;
            query = `${query}|${dt}`;
        }

        loadingBar.classList.remove('hidden');
        searchBtn.disabled = true;


        const skeletonTpl = document.getElementById('skeleton-card-template');
        const skeletonNode = skeletonTpl.content.cloneNode(true);
        const skeletonCard = skeletonNode.querySelector('.skeleton-card');
        container.insertBefore(skeletonCard, container.firstChild);

        await new Promise(r => setTimeout(r, 3000));

        try {
            let result;
            if (window.pywebview && window.pywebview.api) {
                result = await window.pywebview.api.realizar_busqueda(currentSearchType, query);
            } else {
                // Mock behavior
                let mockData = { mock_data: "This is a browser mock", query: query || "unknown" };
                if (currentSearchType === 'qr_generator') {
                    mockData.qr_image_url = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(query || "https://example.com")}`;
                }
                result = {
                    type: currentSearchType,
                    count: Math.floor(Math.random() * 20) + 1,
                    time: 3.01,
                    status: 'exito',
                    data: mockData
                };
            }

            saveToHistory(currentSearchType, searchInput.value.trim() || 'default');

            skeletonCard.remove();

            if (currentSearchType === 'web') {
                addWebGridCard(result, currentIconClass);
            } else {
                addResultCard(result, currentIconClass);
            }


            if (result.db_results && (Array.isArray(result.db_results) ? result.db_results.length > 0 : true)) {
                const dbResultObj = {
                    type: 'database_search',
                    count: Array.isArray(result.db_results) ? result.db_results.length : 1,
                    time: result.time,
                    status: 'exito',
                    data: result.db_results
                };

                addResultCard(dbResultObj, 'ph-database');
            }

            showToast();

        } catch (err) {
            console.error(err);
            skeletonCard.remove();
            alert("Error al contactar con el backend.");
        } finally {
            loadingBar.classList.add('hidden');
            searchBtn.disabled = false;
        }
    }
}

function showToast() {
    let toast = document.getElementById('search-toast');
    if (!toast) {
        toast = document.createElement('div');
        toast.id = 'search-toast';
        toast.className = 'toast-notification';
        toast.innerHTML = `
            <div class="toast-content">
                <i class="ph ph-check-circle" style="color:#10b981; font-size:1.2rem;"></i>
                <span data-i18n="completed">Búsqueda completada</span>
            </div>
        `;
        document.body.appendChild(toast);
    }

    const span = toast.querySelector('span');
    const t = translations[currentLang];
    if (t && t['completed']) {
        span.textContent = t['completed'];
    }

    toast.classList.remove('show');
    void toast.offsetWidth;
    toast.classList.add('show');

    setTimeout(() => {
        toast.classList.remove('show');
    }, 4000);
}

function translateKey(key) {
    const d = translations[currentLang].keys;
    if (d && d[key]) return d[key];
    return key.replace(/_/g, ' ');
}

function renderCleanData(dataObj) {
    if (!dataObj) return '<div class="data-row"><div class="data-key" style="color:var(--text-muted)">Sin datos</div></div>';


    if (typeof dataObj === 'string') {
        return `
            <div class="data-row">
                <div class="data-key">${translateKey("message")}:</div>
                <div class="data-value">${dataObj}</div>
            </div>
        `;
    }

    if (Array.isArray(dataObj)) {
        let items = dataObj.map(item => `<li>${item}</li>`).join('');
        return `<ul style="margin-left: 20px; color: #fff; line-height: 1.8;">${items}</ul>`;
    }

    let html = '';
    for (const [key, val] of Object.entries(dataObj)) {
        const niceKey = translateKey(key);
        let niceVal;

        if (val === true) {
            niceVal = `<span class="data-value bool-true">Activo / True</span>`;
        } else if (val === false) {
            niceVal = `<span class="data-value bool-false">Inactivo / False</span>`;
        } else if (key === 'qr_image_url') {
            niceVal = `
                <div class="data-value">
                    <img src="${val}" alt="QR Code" class="qr-image" />
                </div>
            `;
        } else if (key === 'google_search_link' || (typeof val === 'string' && val.startsWith('http'))) {
            niceVal = `<a href="${val}" target="_blank" class="data-value qr-link">Abrir Enlace / Open Link</a>`;
        } else if (typeof val === 'object' && val !== null) {
            niceVal = `<div class="data-value">${JSON.stringify(val)}</div>`;
            if (Array.isArray(val)) {
                niceVal = `<div class="data-value">${val.join(', ')}</div>`;
            }
        } else {
            niceVal = `<div class="data-value">${val}</div>`;
        }

        html += `
            <div class="data-row">
                <div class="data-key">${niceKey}:</div>
                ${niceVal}
            </div>
        `;
    }
    return html;
}

function addResultCard(resultObj, iconClass) {
    const t = translations[currentLang];
    const template = document.getElementById('result-card-template');
    const clone = template.content.cloneNode(true);
    const card = clone.querySelector('.result-card');

    if (resultObj.type === 'subdomain_finder') {
        card.classList.remove('glass-card-red');
        card.classList.add('glass-card-cyan');
    } else if (resultObj.type === 'database_search') {
        card.classList.remove('glass-card-red');
        card.classList.add('glass-card-orange');
    }

    const niceType = t.labels[resultObj.type] ? t.labels[resultObj.type].toLowerCase() : resultObj.type;
    card.querySelector('.type-val').textContent = niceType;

    if (iconClass) {
        card.querySelector('.tool-icon').innerHTML = `<i class="ph ${iconClass}"></i>`;
    }

    card.querySelector('.count-val').textContent = resultObj.count || 0;
    card.querySelector('.time-val').textContent = resultObj.time || 3.01;

    const dataContainer = card.querySelector('.clean-data-renderer');
    dataContainer.innerHTML = renderCleanData(resultObj.data);

    const expandBtn = card.querySelector('.expand-btn');
    const expandedView = card.querySelector('.expanded-view');
    const icon = expandBtn.querySelector('i');

    expandBtn.addEventListener('click', () => {
        const isMinimized = card.classList.contains('minimized');
        if (isMinimized) {
            card.classList.remove('minimized');
            expandedView.classList.remove('hidden');
            icon.className = 'ph ph-caret-down';
        } else {
            card.classList.add('minimized');
            expandedView.classList.add('hidden');
            icon.className = 'ph ph-caret-right';
        }
    });

    const copyBtn = card.querySelector('.copy-btn');
    copyBtn.addEventListener('click', () => {
        navigator.clipboard.writeText(JSON.stringify(resultObj.data, null, 2));
        const originalIcon = copyBtn.innerHTML;
        copyBtn.innerHTML = '<i class="ph ph-check" style="color:#10b981;"></i>';
        setTimeout(() => { copyBtn.innerHTML = originalIcon; }, 2000);
    });

    const deleteBtn = card.querySelector('.delete-btn');
    deleteBtn.addEventListener('click', () => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(10px)';
        setTimeout(() => { card.remove(); }, 300);
    });

    const container = document.getElementById('results-container');
    container.insertBefore(card, container.firstChild);
}

function addWebGridCard(resultObj, iconClass) {
    const t = translations[currentLang];
    const container = document.getElementById('results-container');


    const wrapper = document.createElement('div');
    wrapper.className = 'web-result-grid animate-in';


    const createSubCard = (title, dataObj, colorClass, gridClass) => {
        const template = document.getElementById('result-card-template');
        const clone = template.content.cloneNode(true);
        const card = clone.querySelector('.result-card');

        card.classList.remove('glass-card-red');
        card.classList.add(colorClass);
        card.classList.add(gridClass);

        const typeSpan = card.querySelector('.type-val');
        typeSpan.textContent = title;

        if (iconClass) {
            card.querySelector('.tool-icon').innerHTML = `<i class="ph ${iconClass}"></i>`;
        }


        let count = 0;
        if (Array.isArray(dataObj)) count = dataObj.length;
        else if (dataObj && typeof dataObj === 'object') count = Object.keys(dataObj).length;


        card.querySelector('.count-val').textContent = count;
        card.querySelector('.time-val').textContent = resultObj.time || 3.01;

        const dataContainer = card.querySelector('.clean-data-renderer');
        dataContainer.innerHTML = renderCleanData(dataObj);

        const expandBtn = card.querySelector('.expand-btn');
        const expandedView = card.querySelector('.expanded-view');
        const icon = expandBtn.querySelector('i');

        expandBtn.addEventListener('click', () => {
            const isMinimized = card.classList.contains('minimized');
            if (isMinimized) {
                card.classList.remove('minimized');
                expandedView.classList.remove('hidden');
                icon.className = 'ph ph-caret-down';
            } else {
                card.classList.add('minimized');
                expandedView.classList.add('hidden');
                icon.className = 'ph ph-caret-right';
            }
        });

        const deleteBtn = card.querySelector('.delete-btn');
        deleteBtn.addEventListener('click', () => {

            wrapper.style.opacity = '0';
            wrapper.style.transform = 'translateY(10px)';
            setTimeout(() => { wrapper.remove(); }, 300);
        });

        const copyBtn = card.querySelector('.copy-btn');
        copyBtn.addEventListener('click', () => {
            navigator.clipboard.writeText(JSON.stringify(dataObj, null, 2));
            const originalIcon = copyBtn.innerHTML;
            copyBtn.innerHTML = '<i class="ph ph-check" style="color:#10b981;"></i>';
            setTimeout(() => { copyBtn.innerHTML = originalIcon; }, 2000);
        });

        // Expanded ONLY for ports if requested, others act like normal cards
        if (gridClass === 'web-panel-ports') {
            card.classList.remove('minimized');
            expandedView.classList.remove('hidden');
            icon.className = 'ph ph-caret-down';
        }

        return card;
    };

    let dInfo = {};
    let dSubs = [];
    let dPorts = {};

    if (resultObj.data) {
        dInfo = resultObj.data.web_details || resultObj.data;
        dSubs = resultObj.data.subdomains_list || [];
        dPorts = resultObj.data.port_scan_log || {};
    }

    const infoCard = createSubCard('Web Info', dInfo, 'glass-card-red', 'web-panel-info');
    const subsCard = createSubCard('Subdominios', dSubs, 'glass-card-cyan', 'web-panel-subs');
    const portsCard = createSubCard('Puertos', dPorts, 'glass-card-green', 'web-panel-ports');

    const leftCol = document.createElement('div');
    leftCol.className = 'web-panel-left';
    leftCol.appendChild(portsCard);

    const rightCol = document.createElement('div');
    rightCol.className = 'web-panel-right';
    rightCol.appendChild(infoCard);
    rightCol.appendChild(subsCard);

    wrapper.appendChild(leftCol);
    wrapper.appendChild(rightCol);

    container.insertBefore(wrapper, container.firstChild);
}

function initParticles() {
    const canvas = document.getElementById('particles-canvas');
    const ctx = canvas.getContext('2d');

    let width, height;
    let particles = [];

    const mouse = { x: null, y: null, radius: 150 };

    window.addEventListener('mousemove', (e) => {
        mouse.x = e.x;
        mouse.y = e.y;
    });

    window.addEventListener('mouseout', () => {
        mouse.x = null;
        mouse.y = null;
    });

    function resize() {
        width = canvas.width = window.innerWidth;
        height = canvas.height = window.innerHeight;
    }

    window.addEventListener('resize', () => {
        resize();
        init();
    });

    class Particle {
        constructor(x, y, dx, dy, size, color) {
            this.x = x;
            this.y = y;
            this.dx = dx;
            this.dy = dy;
            this.size = size;
            this.baseColor = color;
            this.color = color;
            this.baseX = this.x;
            this.baseY = this.y;
            this.density = (Math.random() * 30) + 1;
        }

        draw() {
            ctx.beginPath();
            ctx.arc(this.x, this.y, this.size, 0, Math.PI * 2, false);
            ctx.shadowBlur = 15;
            ctx.shadowColor = this.color;
            ctx.fillStyle = this.color;
            ctx.fill();
        }

        update() {
            if (mouse.x != null && mouse.y != null) {
                let dx = mouse.x - this.x;
                let dy = mouse.y - this.y;
                let distance = Math.sqrt(dx * dx + dy * dy);
                let forceDirectionX = dx / distance;
                let forceDirectionY = dy / distance;

                let maxDistance = mouse.radius;
                let force = (maxDistance - distance) / maxDistance;
                if (force < 0) force = 0;

                let directionX = (forceDirectionX * force * this.density);
                let directionY = (forceDirectionY * force * this.density);

                if (distance < mouse.radius) {
                    this.x -= directionX;
                    this.y -= directionY;
                    this.color = 'rgba(59, 130, 246, 0.8)';
                } else {
                    if (this.x !== this.baseX) {
                        this.x -= (this.x - this.baseX) / 10;
                    }
                    if (this.y !== this.baseY) {
                        this.y -= (this.y - this.baseY) / 10;
                    }
                    this.color = this.baseColor;
                }
            } else {
                if (this.x !== this.baseX) {
                    this.x -= (this.x - this.baseX) / 10;
                }
                if (this.y !== this.baseY) {
                    this.y -= (this.y - this.baseY) / 10;
                }
                this.color = this.baseColor;
            }

            this.baseX += this.dx;
            this.baseY += this.dy;

            if (this.baseX + this.size > width || this.baseX - this.size < 0) this.dx = -this.dx;
            if (this.baseY + this.size > height || this.baseY - this.size < 0) this.dy = -this.dy;

            this.x = this.baseX;
            this.y = this.baseY;

            this.draw();
        }
    }

    function init() {
        particles = [];
        let numParticles = (width * height) / 10000;
        for (let i = 0; i < numParticles; i++) {
            let size = (Math.random() * 2) + 0.5;
            let x = (Math.random() * ((innerWidth - size * 2) - (size * 2)) + size * 2);
            let y = (Math.random() * ((innerHeight - size * 2) - (size * 2)) + size * 2);
            let dx = (Math.random() - 0.5) * 0.5;
            let dy = (Math.random() - 0.5) * 0.5;
            let color = 'rgba(255, 255, 255, 0.15)';

            particles.push(new Particle(x, y, dx, dy, size, color));
        }
    }

    function animate() {
        requestAnimationFrame(animate);
        ctx.clearRect(0, 0, innerWidth, innerHeight);

        for (let i = 0; i < particles.length; i++) {
            particles[i].update();
        }
    }

    resize();
    init();
    animate();
}
